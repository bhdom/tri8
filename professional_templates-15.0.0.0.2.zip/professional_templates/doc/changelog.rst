.. _changelog:

Changelog
=========
`Version 0.0.2 (Wed, 10 Aug 2022 19:29:05 +0300)
-----------------------------------------------------------------
- [FIX] num2words function for invoice is throwing error 'bool' object is not subscriptable.

`Version 0.0.1  (beta) (Wed, 12 Jan 2022 01:20:12 +0300)
-----------------------------------------------------------------
- New module for Odoo 15.0 ported from the same module for odoo 14.0 with same features and settings
